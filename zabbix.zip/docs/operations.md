# Operations notes

Use this folder for runbooks, post-incident notes, version upgrade records, and Zabbix export files. Keep operational decisions close to the Compose stack so another engineer can reconstruct the environment.

## Persistence and automatic restart

The stack is designed so the long-running containers come back automatically after a host reboot, as long as the Docker daemon starts with the operating system:

```sh
sudo systemctl enable --now docker
```

All long-running services in `docker-compose.yml` use `restart: unless-stopped`. This includes Traefik, PostgreSQL, Zabbix Server, Zabbix Web, Zabbix Web Service, Agent 2, SNMP traps, the demo app, and optional proxy/JMX services when those profiles are enabled.

Persistent Zabbix configuration is stored mainly in PostgreSQL under `postgres/data`. This includes hosts, templates, users, dashboards, media types, actions, discovered hosts, history, trends, and frontend configuration. Do not delete or recreate `postgres/data` unless you are intentionally rebuilding or restoring the environment.

Filesystem-backed configuration is mounted from the repository:

- `zabbix/server/alertscripts`, `externalscripts`, `modules`, `enc`, `ssh_keys`, and `mibs`.
- `zabbix/web/modules`.
- `zabbix/web-service/chrome-data`.
- `zabbix/snmptraps` and `zabbix/export`.
- `proxy/*` directories for the optional proxy profile.
- `ZABBIX_NOTIFICATIONS_CONFIG` for the encrypted notification bootstrap configuration.

The notification bootstrap container is intentionally different: `zabbix-notifications-bootstrap` uses `restart: "no"` because it is an idempotent one-shot job. It applies media type configuration into the Zabbix database and then exits. It does not need to run after every reboot if PostgreSQL data is preserved.

Re-run the notification bootstrap when:

- The Zabbix database was freshly rebuilt or restored to a point before notification media types existed.
- `zabbix/notifications/notifications.sops.yaml` changed.
- A webhook script under `zabbix/notifications/media/` changed.

Use:

```sh
docker compose up -d --build --force-recreate zabbix-notifications-bootstrap
docker compose logs zabbix-notifications-bootstrap
```

Before production, confirm the following after a reboot:

```sh
docker compose ps
docker compose logs --tail=100 postgres
docker compose logs --tail=100 zabbix-server
docker compose logs --tail=100 zabbix-web
docker compose logs --tail=100 traefik
```

## Single-disk production layout

For production, keep the repository and runtime data out of a user's home directory even when the server has only one physical disk. Use separate top-level paths so permissions, backups, and capacity checks are clear:

- `/srv/zabbix-stack`: repository, Compose file, scripts, and versioned configuration.
- `/var/lib/zabbix-stack/postgres`: PostgreSQL data. This is the critical persistent state.
- `/var/lib/zabbix-stack/runtime`: Zabbix runtime directories such as traps, export files, and web-service browser data.
- `/var/backups/zabbix-stack`: PostgreSQL dumps and config archives.
- `/var/log/zabbix-stack`: local application logs that are intentionally persisted.
- `/etc/zabbix-stack`: encrypted notification config and secrets such as SOPS age keys, PSKs, certificates, and SSH keys.

Create directories before the first production `docker compose up`:

```sh
sudo mkdir -p \
  /srv/zabbix-stack \
  /var/lib/zabbix-stack/postgres \
  /var/lib/zabbix-stack/runtime/snmptraps \
  /var/lib/zabbix-stack/runtime/export \
  /var/lib/zabbix-stack/runtime/web-service-chrome \
  /var/backups/zabbix-stack/postgres \
  /var/backups/zabbix-stack/config \
  /var/log/zabbix-stack/webapp-demo \
  /etc/zabbix-stack/notifications \
  /etc/zabbix-stack/secrets/zabbix-server-enc \
  /etc/zabbix-stack/secrets/zabbix-server-ssh \
  /etc/zabbix-stack/secrets/zabbix-proxy-enc

sudo chmod 0750 /etc/zabbix-stack /etc/zabbix-stack/secrets
```

Set these variables in production `.env`:

```env
POSTGRES_DATA_DIR=/var/lib/zabbix-stack/postgres
POSTGRES_BACKUP_DIR=/var/backups/zabbix-stack/postgres
ZABBIX_SNMPTRAPS_DIR=/var/lib/zabbix-stack/runtime/snmptraps
ZABBIX_EXPORT_DIR=/var/lib/zabbix-stack/runtime/export
ZABBIX_WEB_SERVICE_CHROME_DIR=/var/lib/zabbix-stack/runtime/web-service-chrome
WEBAPP_DEMO_LOG_DIR=/var/log/zabbix-stack/webapp-demo
ZABBIX_NOTIFICATIONS_CONFIG=/etc/zabbix-stack/notifications/notifications.sops.yaml
ZABBIX_SERVER_ENC_DIR=/etc/zabbix-stack/secrets/zabbix-server-enc
ZABBIX_SERVER_SSH_KEYS_DIR=/etc/zabbix-stack/secrets/zabbix-server-ssh
ZABBIX_PROXY_ENC_DIR=/etc/zabbix-stack/secrets/zabbix-proxy-enc
SOPS_AGE_KEY_FILE=/etc/zabbix-stack/secrets/age.key
```

Do not change `POSTGRES_DATA_DIR` on an existing deployment until the current PostgreSQL data has been copied or restored into the new location. Pointing it at an empty directory creates a fresh Zabbix database.

## Office365 and Teams alerting

Notification configuration lives outside the containers under `zabbix/notifications/`.
The deployable source of truth is `zabbix/notifications/notifications.sops.yaml`, encrypted with SOPS using age.

### Microsoft 365 prerequisites

1. Create an Entra ID app registration for Zabbix alerting.
2. Add Microsoft Graph application permission `Mail.Send`.
3. Grant admin consent for the permission.
4. Create a client secret and store it only in the SOPS-encrypted notification file.
5. Use a dedicated sender mailbox such as `zabbix-alerts@your-domain`.
6. Restrict the app to the sender mailbox with an Exchange Online application access policy when production governance requires it.

### Teams prerequisite

Create a Teams Workflow using the Teams "When a Teams webhook request is received" trigger and copy the generated webhook URL into the SOPS-encrypted notification file.

### Configuration

Fill the notification values in `.env`, then generate the encrypted runtime file:

```sh
./scripts/prepare-zabbix-notifications.sh
```

Start the stack:

```sh
docker compose up -d --build
```

The `zabbix-notifications-bootstrap` service runs automatically after `zabbix-web` is healthy and creates or updates two Zabbix webhook media types:

- `Office365 Graph Mail`
- `Teams Workflow Alert`

After redeploying containers, no image change is required. If the Zabbix database is kept, the media types remain present. For a fresh database restore or rebuild, explicitly recreate the bootstrap job with `docker compose up -d --build --force-recreate zabbix-notifications-bootstrap`.

The bootstrap currently manages media type definitions and webhook script content. It does not create Zabbix users, assign user media, or create trigger actions. Those objects are persisted in PostgreSQL after you configure them in the UI, but they should be exported or documented for repeatable production rebuilds.

### Validation

1. Run `docker compose --env-file .env config`.
2. Run `sops -d ./zabbix/notifications/notifications.sops.yaml`.
3. Run `docker compose up -d --build --force-recreate zabbix-notifications-bootstrap`.
4. Run `docker compose logs zabbix-notifications-bootstrap`.
5. In Zabbix, use the media type test feature for mail and Teams.
6. Confirm the mail arrives from the service mailbox.
7. Confirm Teams receives the workflow message in the intended channel.

Zabbix stores webhook parameters in its database after the bootstrap applies them. Keep PostgreSQL backups encrypted, protect Super admin accounts, and keep the SOPS private key outside this repository.
