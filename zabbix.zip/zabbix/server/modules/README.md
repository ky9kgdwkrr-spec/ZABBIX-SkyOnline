# Server modules

Place custom Zabbix server modules here only when required. Keep binaries version-controlled by source or artifact process, not edited in-place.

