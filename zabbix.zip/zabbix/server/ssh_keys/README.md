# SSH keys

Place SSH keys used by Zabbix checks here. Restrict permissions and prefer dedicated least-privilege accounts.

