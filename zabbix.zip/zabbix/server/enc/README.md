# Encryption material

Place TLS PSK/certificate files here when enabling encrypted agent, proxy, or trap communication. Restrict filesystem permissions in production.

