# Web TLS material

Reserved for TLS files used by the official Zabbix Nginx image. This stack publishes plain HTTP by default and expects TLS to be added at an external reverse proxy when needed.

