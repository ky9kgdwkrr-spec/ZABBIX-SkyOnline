# Web modules

Place Zabbix frontend modules here if your environment uses frontend extensions.

