var TeamsWorkflowAlert = {
    required: [
        'workflow_url',
        'subject',
        'message'
    ],

    validate: function (params) {
        this.required.forEach(function (name) {
            if (!params[name]) {
                throw 'Missing required parameter: ' + name;
            }
        });
    },

    send: function (params) {
        var request = new HttpRequest(),
            payload,
            response,
            status;

        payload = {
            text: params.subject + '\n\n' + params.message,
            subject: params.subject,
            message: params.message,
            severity: params.severity || '',
            event_id: params.event_id || '',
            event_status: params.event_status || '',
            host: params.host || ''
        };

        request.addHeader('Content-Type: application/json');
        response = request.post(params.workflow_url, JSON.stringify(payload));
        status = request.getStatus();

        if (status < 200 || status >= 300) {
            throw 'Teams Workflow webhook failed with HTTP ' + status + ': ' + response;
        }
    }
};

try {
    var params = JSON.parse(value);

    TeamsWorkflowAlert.validate(params);
    TeamsWorkflowAlert.send(params);

    return JSON.stringify({
        status: 'sent'
    });
}
catch (error) {
    Zabbix.log(3, '[Teams Workflow Alert] ' + error);
    throw String(error);
}

