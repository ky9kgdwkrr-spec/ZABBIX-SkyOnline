#!/bin/sh
set -eu

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
  CREATE USER ${ZBX_PROXY_DB_USER:-zabbix_proxy} WITH PASSWORD '${ZBX_PROXY_DB_PASSWORD:-change-me-zabbix-proxy-db-password}';
  CREATE DATABASE ${ZBX_PROXY_DB:-zabbix_proxy} OWNER ${ZBX_PROXY_DB_USER:-zabbix_proxy};
EOSQL

