#!/usr/bin/env sh
set -eu

timestamp="$(date -u +%Y%m%d-%H%M%S)"
backup_dir="${POSTGRES_BACKUP_DIR:-$(CDPATH= cd -- "$(dirname -- "$0")/../backups/postgres" && pwd)}"
mkdir -p "${backup_dir}"
backup_file="${backup_dir}/zabbix-${timestamp}.dump"

docker compose exec -T postgres sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > "${backup_file}"
echo "Backup written to ${backup_file}"
