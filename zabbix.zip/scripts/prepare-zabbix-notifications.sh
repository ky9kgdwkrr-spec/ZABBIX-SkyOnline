#!/usr/bin/env sh
set -eu

ENV_FILE="${ENV_FILE:-.env}"
CONFIG_DIR="${CONFIG_DIR:-zabbix/notifications}"
KEY_FILE="${SOPS_AGE_KEY_FILE:-${CONFIG_DIR}/keys/age.key}"
PLAIN_FILE="${CONFIG_DIR}/notifications.plain.yaml"
SOPS_FILE="${CONFIG_DIR}/notifications.sops.yaml"

case "${ENV_FILE}" in
  /*|./*|../*) ENV_SOURCE="${ENV_FILE}" ;;
  *) ENV_SOURCE="./${ENV_FILE}" ;;
esac

if [ ! -f "${ENV_SOURCE}" ]; then
  echo "Environment file not found: ${ENV_SOURCE}" >&2
  echo "Use ENV_FILE=.env.wsl.runtime or ENV_FILE=.env.prod.runtime after preparing runtime env." >&2
  exit 1
fi

if ! command -v sops >/dev/null 2>&1; then
  echo "sops is required but was not found in PATH." >&2
  exit 1
fi

if ! command -v age-keygen >/dev/null 2>&1; then
  echo "age-keygen is required but was not found in PATH." >&2
  exit 1
fi

NORMALIZED_ENV="$(mktemp)"
sed 's/\r$//' "${ENV_SOURCE}" > "${NORMALIZED_ENV}"

set -a
# shellcheck disable=SC1090
. "${NORMALIZED_ENV}"
set +a
rm -f "${NORMALIZED_ENV}"

require_var() {
  name="$1"
  eval "value=\${$name:-}"
  if [ -z "${value}" ] || [ "${value#change-me}" != "${value}" ] || [ "${value#__from_}" != "${value}" ]; then
    echo "Missing or placeholder value in ${ENV_SOURCE}: ${name}" >&2
    exit 1
  fi
}

require_var ZABBIX_ADMIN_PASSWORD
require_var OFFICE365_TENANT_ID
require_var OFFICE365_CLIENT_ID
require_var OFFICE365_CLIENT_SECRET
require_var OFFICE365_SENDER_UPN
require_var OFFICE365_DEFAULT_RECIPIENTS
require_var TEAMS_WORKFLOW_URL

yaml_quote() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/^/"/; s/$/"/'
}

mkdir -p "${CONFIG_DIR}/keys"

if [ ! -f "${KEY_FILE}" ]; then
  mkdir -p "$(dirname "${KEY_FILE}")"
  age-keygen -o "${KEY_FILE}"
  chmod 0600 "${KEY_FILE}" || true
fi

AGE_RECIPIENT="$(awk '/^# public key: / {print $4; exit}' "${KEY_FILE}")"
if [ -z "${AGE_RECIPIENT}" ]; then
  echo "Could not read age recipient from ${KEY_FILE}" >&2
  exit 1
fi

cat > "${PLAIN_FILE}" <<EOF
zabbix:
  api_url: http://zabbix-web:8080/api_jsonrpc.php
  api_token:
  username: $(yaml_quote "${ZABBIX_ADMIN_USER:-Admin}")
  password: $(yaml_quote "${ZABBIX_ADMIN_PASSWORD}")

office365:
  tenant_id: $(yaml_quote "${OFFICE365_TENANT_ID}")
  client_id: $(yaml_quote "${OFFICE365_CLIENT_ID}")
  client_secret: $(yaml_quote "${OFFICE365_CLIENT_SECRET}")
  sender_upn: $(yaml_quote "${OFFICE365_SENDER_UPN}")
  default_mail_recipients:
EOF

printf '%s' "${OFFICE365_DEFAULT_RECIPIENTS}" | tr ',' '\n' | while IFS= read -r recipient; do
  trimmed="$(printf '%s' "${recipient}" | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
  if [ -n "${trimmed}" ]; then
    printf '    - %s\n' "$(yaml_quote "${trimmed}")" >> "${PLAIN_FILE}"
  fi
done

cat >> "${PLAIN_FILE}" <<EOF

teams:
  workflow_url: $(yaml_quote "${TEAMS_WORKFLOW_URL}")
EOF

sops --encrypt --age "${AGE_RECIPIENT}" --input-type yaml --output-type yaml "${PLAIN_FILE}" > "${SOPS_FILE}"
rm -f "${PLAIN_FILE}"

echo "Encrypted notification config written to ${SOPS_FILE}"
echo "SOPS age key available at ${KEY_FILE}"
