#!/usr/bin/env sh
set -eu

ENV_FILE="${ENV_FILE:-.env}"
PASSWORD="${ADMIN_APP_PASSWORD:-}"

case "${ENV_FILE}" in
  /*|./*|../*) ENV_SOURCE="${ENV_FILE}" ;;
  *) ENV_SOURCE="./${ENV_FILE}" ;;
esac

if [ ! -f "${ENV_SOURCE}" ]; then
  echo "Environment file not found: ${ENV_SOURCE}" >&2
  exit 1
fi

if [ -z "${PASSWORD}" ]; then
  echo "Set ADMIN_APP_PASSWORD before running this script." >&2
  exit 1
fi

if ! command -v sops >/dev/null 2>&1; then
  echo "sops is required but was not found in PATH." >&2
  exit 1
fi

if ! command -v age-keygen >/dev/null 2>&1; then
  echo "age-keygen is required but was not found in PATH." >&2
  exit 1
fi

NORMALIZED_ENV="$(mktemp)"
sed 's/\r$//' "${ENV_SOURCE}" > "${NORMALIZED_ENV}"

set -a
# shellcheck disable=SC1090
. "${NORMALIZED_ENV}"
set +a
rm -f "${NORMALIZED_ENV}"

KEY_FILE="${SOPS_AGE_KEY_FILE:-zabbix/notifications/keys/age.key}"
SECRETS_FILE="${ADMIN_SECRETS_FILE:-zabbix/admin-secrets/admin-passwords.sops.env}"
PLAIN_FILE="$(dirname "${SECRETS_FILE}")/admin-passwords.plain.env"

mkdir -p "$(dirname "${KEY_FILE}")" "$(dirname "${SECRETS_FILE}")"

if [ ! -e "${KEY_FILE}" ]; then
  age-keygen -o "${KEY_FILE}"
  chmod 0600 "${KEY_FILE}" || true
fi

if [ ! -f "${KEY_FILE}" ]; then
  echo "SOPS age key path exists but is not a regular file: ${KEY_FILE}" >&2
  exit 1
fi

if [ ! -r "${KEY_FILE}" ]; then
  echo "SOPS age key exists but is not readable: ${KEY_FILE}" >&2
  exit 1
fi

AGE_RECIPIENT="$(awk '/^# public key: / {print $4; exit}' "${KEY_FILE}")"
if [ -z "${AGE_RECIPIENT}" ]; then
  echo "Could not read age recipient from ${KEY_FILE}" >&2
  exit 1
fi

cat > "${PLAIN_FILE}" <<EOF
ZABBIX_ADMIN_PASSWORD=${PASSWORD}
AIRFLOW_ADMIN_PASSWORD=${PASSWORD}
EOF

sops --encrypt --age "${AGE_RECIPIENT}" --input-type dotenv --output-type dotenv "${PLAIN_FILE}" > "${SECRETS_FILE}"
rm -f "${PLAIN_FILE}"
chmod 0600 "${SECRETS_FILE}" || true

echo "Encrypted admin secrets written to ${SECRETS_FILE}"
echo "SOPS age key available at ${KEY_FILE}"
