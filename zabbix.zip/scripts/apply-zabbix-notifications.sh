#!/usr/bin/env sh
set -eu

CONFIG_PATH="${NOTIFICATIONS_CONFIG:-zabbix/notifications/notifications.sops.yaml}"
OFFICE365_SCRIPT_PATH="${OFFICE365_SCRIPT:-zabbix/notifications/media/office365-graph-mail.js}"
TEAMS_SCRIPT_PATH="${TEAMS_SCRIPT:-zabbix/notifications/media/teams-workflow-alert.js}"
DRY_RUN="${DRY_RUN:-0}"

if [ ! -f "${CONFIG_PATH}" ]; then
  echo "Notification config not found: ${CONFIG_PATH}" >&2
  echo "Create zabbix/notifications/notifications.sops.yaml before starting the stack." >&2
  exit 1
fi

if ! command -v sops >/dev/null 2>&1; then
  echo "sops is required but was not found in PATH." >&2
  exit 1
fi

tmp_config="$(mktemp)"
trap 'rm -f "${tmp_config}"' EXIT

sops --decrypt --output-type json "${CONFIG_PATH}" > "${tmp_config}"

CONFIG_JSON="${tmp_config}" \
OFFICE365_SCRIPT_PATH="${OFFICE365_SCRIPT_PATH}" \
TEAMS_SCRIPT_PATH="${TEAMS_SCRIPT_PATH}" \
DRY_RUN="${DRY_RUN}" \
python3 - <<'PY'
import json
import os
import sys
import time
import urllib.error
import urllib.request


def read_json(path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


def read_text(path):
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def config_value(config, section, name, required=True, default=None):
    value = default
    if isinstance(config.get(section), dict) and name in config[section]:
        value = config[section][name]
    elif name in config:
        value = config[name]

    if required and (value is None or str(value).strip() == ""):
        raise RuntimeError(f"Missing required configuration value: {section}.{name}")
    return value


def normalize_token(value):
    if value is None:
        return None
    value = str(value).strip()
    if not value or value.startswith("change-me"):
        return None
    return value


def zabbix_request(api_url, method, params=None, api_token=None, session_auth=None, retries=30):
    params = params or {}
    body = {
        "jsonrpc": "2.0",
        "method": method,
        "params": params,
        "id": 1,
    }
    if session_auth:
        body["auth"] = session_auth

    payload = json.dumps(body).encode("utf-8")
    headers = {
        "Content-Type": "application/json-rpc",
    }
    if api_token:
        headers["Authorization"] = f"Bearer {api_token}"

    last_error = None
    for attempt in range(1, retries + 1):
        try:
            request = urllib.request.Request(api_url, data=payload, headers=headers, method="POST")
            with urllib.request.urlopen(request, timeout=15) as response:
                data = json.loads(response.read().decode("utf-8"))
            if "error" in data:
                error = data["error"]
                raise RuntimeError(f"{method} failed: {error.get('message')} {error.get('data')}")
            return data.get("result")
        except (urllib.error.URLError, TimeoutError, RuntimeError) as exc:
            last_error = exc
            if attempt == retries:
                break
            time.sleep(5)

    raise RuntimeError(f"Zabbix API request did not succeed after {retries} attempts: {last_error}")


def parameter(name, value):
    return {
        "name": name,
        "value": "" if value is None else str(value),
    }


def message_templates():
    return [
        {
            "eventsource": "0",
            "recovery": "0",
            "subject": "Problem: {EVENT.NAME}",
            "message": "\n".join([
                "Problem started at {EVENT.TIME} on {EVENT.DATE}",
                "Host: {HOST.NAME}",
                "Severity: {EVENT.SEVERITY}",
                "Operational data: {EVENT.OPDATA}",
                "Event ID: {EVENT.ID}",
                "Problem: {EVENT.NAME}",
            ]),
        },
        {
            "eventsource": "0",
            "recovery": "1",
            "subject": "Resolved in {EVENT.DURATION}: {EVENT.NAME}",
            "message": "\n".join([
                "Problem resolved at {EVENT.RECOVERY.TIME} on {EVENT.RECOVERY.DATE}",
                "Host: {HOST.NAME}",
                "Severity: {EVENT.SEVERITY}",
                "Duration: {EVENT.DURATION}",
                "Event ID: {EVENT.ID}",
                "Problem: {EVENT.NAME}",
            ]),
        },
        {
            "eventsource": "0",
            "recovery": "2",
            "subject": "Updated problem in {EVENT.AGE}: {EVENT.NAME}",
            "message": "\n".join([
                "Problem updated by {USER.FULLNAME} at {EVENT.UPDATE.TIME} on {EVENT.UPDATE.DATE}",
                "Host: {HOST.NAME}",
                "Severity: {EVENT.SEVERITY}",
                "Update action: {EVENT.UPDATE.ACTION}",
                "Update message: {EVENT.UPDATE.MESSAGE}",
                "Event ID: {EVENT.ID}",
                "Problem: {EVENT.NAME}",
            ]),
        },
    ]


def set_media_type(api_url, api_token, session_auth, definition, dry_run):
    existing = zabbix_request(
        api_url,
        "mediatype.get",
        {
            "output": ["mediatypeid", "name"],
            "filter": {
                "name": [definition["name"]],
            },
        },
        api_token=api_token,
        session_auth=session_auth,
    )

    if existing:
        media_type_id = existing[0]["mediatypeid"]
        update = dict(definition)
        update["mediatypeid"] = media_type_id
        if dry_run:
            print(f"DRY RUN: would update media type '{definition['name']}' ({media_type_id})")
            return
        zabbix_request(api_url, "mediatype.update", update, api_token=api_token, session_auth=session_auth)
        print(f"Updated media type '{definition['name']}' ({media_type_id})")
        return

    if dry_run:
        print(f"DRY RUN: would create media type '{definition['name']}'")
        return

    created = zabbix_request(api_url, "mediatype.create", definition, api_token=api_token, session_auth=session_auth)
    print(f"Created media type '{definition['name']}' ({', '.join(created['mediatypeids'])})")


config = read_json(os.environ["CONFIG_JSON"])
api_url = config_value(config, "zabbix", "api_url")
api_token = normalize_token(config_value(config, "zabbix", "api_token", required=False))
api_user = config_value(config, "zabbix", "username", required=False, default="Admin")
api_password = config_value(config, "zabbix", "password", required=False)

tenant_id = config_value(config, "office365", "tenant_id")
client_id = config_value(config, "office365", "client_id")
client_secret = config_value(config, "office365", "client_secret")
sender_upn = config_value(config, "office365", "sender_upn")
default_recipients = config_value(config, "office365", "default_mail_recipients")
teams_workflow_url = config_value(config, "teams", "workflow_url")

if isinstance(default_recipients, list):
    default_recipients = ",".join(default_recipients)

zabbix_request(api_url, "apiinfo.version", {}, retries=60)

session_auth = None
if not api_token:
    if not api_password:
        raise RuntimeError("Set zabbix.api_token or zabbix.password in notifications.sops.yaml.")
    session_auth = zabbix_request(
        api_url,
        "user.login",
        {
            "username": api_user,
            "password": api_password,
        },
        retries=12,
    )

templates = message_templates()
office365_script = read_text(os.environ["OFFICE365_SCRIPT_PATH"])
teams_script = read_text(os.environ["TEAMS_SCRIPT_PATH"])
dry_run = os.environ.get("DRY_RUN") == "1"

office365_media_type = {
    "type": "4",
    "name": "Office365 Graph Mail",
    "status": "0",
    "maxattempts": "3",
    "attempt_interval": "10s",
    "timeout": "30s",
    "process_tags": "0",
    "description": "Sends Zabbix alerts through Microsoft Graph sendMail. Managed by scripts/apply-zabbix-notifications.sh.",
    "script": office365_script,
    "parameters": [
        parameter("tenant_id", tenant_id),
        parameter("client_id", client_id),
        parameter("client_secret", client_secret),
        parameter("sender_upn", sender_upn),
        parameter("to", "{ALERT.SENDTO}"),
        parameter("default_to", default_recipients),
        parameter("subject", "{ALERT.SUBJECT}"),
        parameter("message", "{ALERT.MESSAGE}"),
    ],
    "message_templates": templates,
}

teams_media_type = {
    "type": "4",
    "name": "Teams Workflow Alert",
    "status": "0",
    "maxattempts": "3",
    "attempt_interval": "10s",
    "timeout": "30s",
    "process_tags": "0",
    "description": "Sends Zabbix alerts to Microsoft Teams through a Teams Workflows webhook. Managed by scripts/apply-zabbix-notifications.sh.",
    "script": teams_script,
    "parameters": [
        parameter("workflow_url", teams_workflow_url),
        parameter("subject", "{ALERT.SUBJECT}"),
        parameter("message", "{ALERT.MESSAGE}"),
        parameter("severity", "{EVENT.SEVERITY}"),
        parameter("event_id", "{EVENT.ID}"),
        parameter("event_status", "{EVENT.STATUS}"),
        parameter("host", "{HOST.NAME}"),
    ],
    "message_templates": templates,
}

set_media_type(api_url, api_token, session_auth, office365_media_type, dry_run)
set_media_type(api_url, api_token, session_auth, teams_media_type, dry_run)
PY

