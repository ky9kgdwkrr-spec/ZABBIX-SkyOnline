#!/usr/bin/env sh
set -eu

ENV_FILE="${ENV_FILE:-}"
if [ -n "${ENV_FILE}" ]; then
  case "${ENV_FILE}" in
    /*|./*|../*) ENV_SOURCE="${ENV_FILE}" ;;
    *) ENV_SOURCE="./${ENV_FILE}" ;;
  esac

  if [ ! -f "${ENV_SOURCE}" ]; then
    echo "Environment file not found: ${ENV_SOURCE}" >&2
    exit 1
  fi

  NORMALIZED_ENV="$(mktemp)"
  sed 's/\r$//' "${ENV_SOURCE}" > "${NORMALIZED_ENV}"
  set -a
  # shellcheck disable=SC1090
  . "${NORMALIZED_ENV}"
  set +a
  rm -f "${NORMALIZED_ENV}"
fi

CERT_DIR="${TRAEFIK_CERTS_DIR:-traefik/certs}"
DAYS="${TRAEFIK_SELF_SIGNED_DAYS:-365}"

mkdir -p "$CERT_DIR"

openssl req \
  -x509 \
  -nodes \
  -newkey rsa:4096 \
  -sha256 \
  -days "$DAYS" \
  -keyout "$CERT_DIR/overlabs.key" \
  -out "$CERT_DIR/overlabs.crt" \
  -subj "/CN=overlabs.com" \
  -addext "subjectAltName=DNS:zabbix.overlabs.com,DNS:traefik.overlabs.com,DNS:airflow.overlabs.com,DNS:overlabs.com"

chmod 0600 "$CERT_DIR/overlabs.key"
chmod 0644 "$CERT_DIR/overlabs.crt"

printf 'Generated %s/overlabs.crt and %s/overlabs.key\n' "$CERT_DIR" "$CERT_DIR"
