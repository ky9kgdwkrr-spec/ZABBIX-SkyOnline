#!/usr/bin/env sh
set -eu

ENV_FILE="${ENV_FILE:-.env}"
if [ -z "${RUNTIME_ENV_FILE:-}" ]; then
  RUNTIME_ENV_FILE="${ENV_FILE}.runtime"
fi

case "${ENV_FILE}" in
  /*|./*|../*) ENV_SOURCE="${ENV_FILE}" ;;
  *) ENV_SOURCE="./${ENV_FILE}" ;;
esac

if [ ! -f "${ENV_SOURCE}" ]; then
  echo "Environment file not found: ${ENV_SOURCE}" >&2
  exit 1
fi

if ! command -v sops >/dev/null 2>&1; then
  echo "sops is required but was not found in PATH." >&2
  exit 1
fi

NORMALIZED_ENV="$(mktemp)"
sed 's/\r$//' "${ENV_SOURCE}" > "${NORMALIZED_ENV}"

set -a
# shellcheck disable=SC1090
. "${NORMALIZED_ENV}"
set +a

SECRETS_FILE="${ADMIN_SECRETS_FILE:-zabbix/admin-secrets/admin-passwords.sops.env}"
if [ ! -f "${SECRETS_FILE}" ]; then
  echo "Encrypted admin secrets file not found: ${SECRETS_FILE}" >&2
  echo "Run scripts/prepare-admin-secrets.sh first." >&2
  exit 1
fi

awk '
  /^[[:space:]]*(ZABBIX_ADMIN_PASSWORD|AIRFLOW_ADMIN_PASSWORD)=/ { next }
  { print }
' "${NORMALIZED_ENV}" > "${RUNTIME_ENV_FILE}"
rm -f "${NORMALIZED_ENV}"

{
  printf '\n# Decrypted admin secrets. Do not commit this file.\n'
  sops --decrypt --input-type dotenv --output-type dotenv "${SECRETS_FILE}"
} >> "${RUNTIME_ENV_FILE}"

chmod 0600 "${RUNTIME_ENV_FILE}" || true
echo "Runtime environment written to ${RUNTIME_ENV_FILE}"
