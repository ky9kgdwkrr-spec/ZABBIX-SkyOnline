#!/usr/bin/env sh
set -eu

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 backups/postgres/zabbix-YYYYMMDD-HHMMSS.dump" >&2
  exit 1
fi

backup_file="$1"
test -f "${backup_file}"

docker compose stop zabbix-web zabbix-server zabbix-proxy || true
docker compose exec -T postgres sh -c 'dropdb -U "$POSTGRES_USER" --if-exists "$POSTGRES_DB"'
docker compose exec -T postgres sh -c 'createdb -U "$POSTGRES_USER" "$POSTGRES_DB"'
docker compose exec -T postgres sh -c 'pg_restore -U "$POSTGRES_USER" -d "$POSTGRES_DB" --clean --if-exists' < "${backup_file}"
docker compose up -d zabbix-server zabbix-web
