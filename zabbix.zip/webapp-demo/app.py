import json
import os
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

START_TIME = time.time()
LOG_PATH = "/app/logs/access.log"


class Handler(BaseHTTPRequestHandler):
    server_version = "zbx-demo-webapp/1.0"

    def _write_json(self, code, payload):
        body = json.dumps(payload, sort_keys=True).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _log_access(self, code):
        os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
        with open(LOG_PATH, "a", encoding="utf-8") as log:
            log.write(f"{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} {self.client_address[0]} {self.command} {self.path} {code}\n")

    def do_GET(self):
        if self.path == "/":
            payload = {
                "service": os.getenv("APP_NAME", "webapp-demo"),
                "message": "Zabbix demo web application",
                "endpoints": ["/", "/health", "/info"],
            }
            code = 200
        elif self.path == "/health":
            payload = {"status": "ok", "uptime_seconds": int(time.time() - START_TIME)}
            code = 200
        elif self.path == "/info":
            payload = {
                "service": os.getenv("APP_NAME", "webapp-demo"),
                "environment": os.getenv("APP_ENV", "local"),
                "hostname": os.uname().nodename,
                "python": ".".join(map(str, os.sys.version_info[:3])),
            }
            code = 200
        else:
            payload = {"error": "not_found"}
            code = 404

        self._write_json(code, payload)
        self._log_access(code)

    def log_message(self, fmt, *args):
        return


if __name__ == "__main__":
    server = ThreadingHTTPServer(("0.0.0.0", 8080), Handler)
    server.serve_forever()

