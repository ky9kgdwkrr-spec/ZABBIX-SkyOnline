# Runbook de despliegue

Este archivo contiene los comandos directos para levantar todo el stack.

Airflow ya no usa `--profile`: levanta siempre junto con Zabbix.

## 1. WSL / Validacion local

Ejecutar desde el directorio del repo:

```bash
cd ~/ZABBIX-SKYONLINE
```

Instalar prerequisitos si faltan:

```bash
sudo apt update
sudo apt install -y curl age openssl

SOPS_VERSION=v3.13.1
curl -LO "https://github.com/getsops/sops/releases/download/${SOPS_VERSION}/sops-${SOPS_VERSION}.linux.amd64"
sudo mv "sops-${SOPS_VERSION}.linux.amd64" /usr/local/bin/sops
sudo chmod +x /usr/local/bin/sops

sops --version
age-keygen --version
```

Editar `.env.wsl` y reemplazar los valores `change-me-*`, especialmente:

```bash
nano .env.wsl
```

Generar claves de Airflow y pegarlas en `.env.wsl`:

```bash
python3 - <<'PY'
import base64
import os
import secrets
print("AIRFLOW_FERNET_KEY=" + base64.urlsafe_b64encode(os.urandom(32)).decode())
print("AIRFLOW_SECRET_KEY=" + secrets.token_urlsafe(48))
PY
```

Preparar secretos admin, runtime env y certificado local:

```bash
ENV_FILE=.env.wsl
ADMIN_APP_PASSWORD='Directv.00001!' ENV_FILE="$ENV_FILE" sh scripts/prepare-admin-secrets.sh
ENV_FILE="$ENV_FILE" sh scripts/prepare-runtime-env.sh
ENV_FILE="$ENV_FILE" sh scripts/generate-traefik-self-signed-cert.sh
chmod 600 "$ENV_FILE.runtime"
```

Validar Compose:

```bash
docker compose --env-file .env.wsl.runtime config
```

Levantar todo el stack:

```bash
docker compose --env-file .env.wsl.runtime up -d --build
```

Ver estado y logs:

```bash
docker compose --env-file .env.wsl.runtime ps
docker compose --env-file .env.wsl.runtime logs --tail=100 traefik
docker compose --env-file .env.wsl.runtime logs --tail=100 zabbix-server
docker compose --env-file .env.wsl.runtime logs --tail=100 zabbix-web
docker compose --env-file .env.wsl.runtime logs --tail=100 airflow-apiserver
```

Si Airflow ya estaba creado antes del cambio a FAB auth manager, recrear sus servicios:

```bash
docker compose --env-file .env.wsl.runtime up -d --force-recreate airflow-init airflow-apiserver airflow-scheduler airflow-dag-processor airflow-triggerer
docker compose --env-file .env.wsl.runtime exec airflow-apiserver airflow config get-value core auth_manager
```

Validar acceso HTTPS local:

```bash
curl -k -I -H "Host: zabbix.overlabs.com" https://localhost/
curl -k -I -H "Host: traefik.overlabs.com" https://localhost/dashboard/
curl -k -I -H "Host: airflow.overlabs.com" https://localhost/
```

URLs:

```text
https://zabbix.overlabs.com/
https://traefik.overlabs.com/dashboard/
https://airflow.overlabs.com/
```

## 2. Produccion

Ejecutar desde el directorio productivo del repo:

```bash
cd /srv/zabbix-stack
```

Instalar prerequisitos si faltan:

```bash
sudo apt update
sudo apt install -y curl age openssl

SOPS_VERSION=v3.13.1
curl -LO "https://github.com/getsops/sops/releases/download/${SOPS_VERSION}/sops-${SOPS_VERSION}.linux.amd64"
sudo mv "sops-${SOPS_VERSION}.linux.amd64" /usr/local/bin/sops
sudo chmod +x /usr/local/bin/sops

sops --version
age-keygen --version
```

Crear directorios productivos:

```bash
sudo mkdir -p \
  /srv/zabbix-stack \
  /var/lib/zabbix-stack/postgres \
  /var/lib/zabbix-stack/runtime/snmptraps \
  /var/lib/zabbix-stack/runtime/export \
  /var/lib/zabbix-stack/runtime/web-service-chrome \
  /var/lib/zabbix-stack/airflow-postgres \
  /var/backups/zabbix-stack/postgres \
  /var/backups/zabbix-stack/config \
  /var/log/zabbix-stack/webapp-demo \
  /var/log/zabbix-stack/airflow \
  /srv/zabbix-stack/airflow/dags \
  /srv/zabbix-stack/airflow/plugins \
  /etc/zabbix-stack/notifications \
  /etc/zabbix-stack/traefik/certs \
  /etc/zabbix-stack/airflow/config \
  /etc/zabbix-stack/secrets/zabbix-server-enc \
  /etc/zabbix-stack/secrets/zabbix-server-ssh \
  /etc/zabbix-stack/secrets/zabbix-proxy-enc

sudo chmod 0750 /etc/zabbix-stack /etc/zabbix-stack/secrets
sudo chmod 0750 /etc/zabbix-stack/traefik /etc/zabbix-stack/traefik/certs
```

Editar `.env.prod` y reemplazar los valores `change-me-*`, especialmente:

```bash
nano .env.prod
```

Generar claves de Airflow y pegarlas en `.env.prod`:

```bash
python3 - <<'PY'
import base64
import os
import secrets
print("AIRFLOW_FERNET_KEY=" + base64.urlsafe_b64encode(os.urandom(32)).decode())
print("AIRFLOW_SECRET_KEY=" + secrets.token_urlsafe(48))
PY
```

Preparar secretos admin, runtime env y certificado temporal:

```bash
ENV_FILE=.env.prod
sudo ADMIN_APP_PASSWORD='Directv.00001!' ENV_FILE="$ENV_FILE" sh scripts/prepare-admin-secrets.sh
sudo ENV_FILE="$ENV_FILE" sh scripts/prepare-runtime-env.sh
sudo ENV_FILE="$ENV_FILE" sh scripts/generate-traefik-self-signed-cert.sh
sudo chmod 600 "$ENV_FILE.runtime"
```

Validar Compose:

```bash
sudo docker compose --env-file .env.prod.runtime config
```

Levantar todo el stack:

```bash
sudo docker compose --env-file .env.prod.runtime up -d --build
```

Ver estado y logs:

```bash
sudo docker compose --env-file .env.prod.runtime ps
sudo docker compose --env-file .env.prod.runtime logs --tail=100 traefik
sudo docker compose --env-file .env.prod.runtime logs --tail=100 zabbix-server
sudo docker compose --env-file .env.prod.runtime logs --tail=100 zabbix-web
sudo docker compose --env-file .env.prod.runtime logs --tail=100 airflow-apiserver
```

Si Airflow ya estaba creado antes del cambio a FAB auth manager, recrear sus servicios:

```bash
sudo docker compose --env-file .env.prod.runtime up -d --force-recreate airflow-init airflow-apiserver airflow-scheduler airflow-dag-processor airflow-triggerer
sudo docker compose --env-file .env.prod.runtime exec airflow-apiserver airflow config get-value core auth_manager
```

Validar acceso HTTPS:

```bash
curl -k -I -H "Host: zabbix.overlabs.com" https://localhost/
curl -k -I -H "Host: traefik.overlabs.com" https://localhost/dashboard/
curl -k -I -H "Host: airflow.overlabs.com" https://localhost/
```

Habilitar Docker al reiniciar el servidor:

```bash
sudo systemctl enable --now docker
```

Firewall base recomendado:

```bash
sudo ufw allow 443/tcp
sudo ufw allow 10051/tcp
sudo ufw deny 10050/tcp
sudo ufw deny 1162/udp
sudo ufw status verbose
```

URLs:

```text
https://zabbix.overlabs.com/
https://traefik.overlabs.com/dashboard/
https://airflow.overlabs.com/
```

## 3. Comandos utiles

Actualizar imagenes y recrear:

```bash
docker compose --env-file .env.wsl.runtime pull
docker compose --env-file .env.wsl.runtime up -d --build
```

En produccion:

```bash
sudo docker compose --env-file .env.prod.runtime pull
sudo docker compose --env-file .env.prod.runtime up -d --build
```

Apagar sin borrar datos:

```bash
docker compose --env-file .env.wsl.runtime down
```

En produccion:

```bash
sudo docker compose --env-file .env.prod.runtime down
```
