# Proxy encryption material

TLS PSK/certificate material for the optional Zabbix proxy.

