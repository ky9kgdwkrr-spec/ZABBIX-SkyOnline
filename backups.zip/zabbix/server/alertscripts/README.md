# Alert scripts

Place custom Zabbix alert scripts here. The directory is mounted read-only into `zabbix-server` at `/usr/lib/zabbix/alertscripts`.

