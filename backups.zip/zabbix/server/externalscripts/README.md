# External scripts

Place custom external check scripts here. The directory is mounted read-only into `zabbix-server` at `/usr/lib/zabbix/externalscripts`.

