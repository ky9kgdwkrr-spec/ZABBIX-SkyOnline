# SNMP MIBs

Place vendor MIB files here. The directory is mounted into the server and SNMP trap receiver.

