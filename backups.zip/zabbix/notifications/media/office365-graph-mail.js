var Office365GraphMail = {
    required: [
        'tenant_id',
        'client_id',
        'client_secret',
        'sender_upn',
        'subject',
        'message'
    ],

    validate: function (params) {
        this.required.forEach(function (name) {
            if (!params[name]) {
                throw 'Missing required parameter: ' + name;
            }
        });
    },

    parseRecipients: function (value) {
        return String(value)
            .split(/[;,]/)
            .map(function (recipient) {
                return recipient.trim();
            })
            .filter(function (recipient) {
                return recipient.length > 0;
            })
            .map(function (recipient) {
                return {
                    emailAddress: {
                        address: recipient
                    }
                };
            });
    },

    requestToken: function (params) {
        var request = new HttpRequest(),
            tokenUrl = 'https://login.microsoftonline.com/' + encodeURIComponent(params.tenant_id) + '/oauth2/v2.0/token',
            body = [
                'client_id=' + encodeURIComponent(params.client_id),
                'client_secret=' + encodeURIComponent(params.client_secret),
                'scope=' + encodeURIComponent('https://graph.microsoft.com/.default'),
                'grant_type=client_credentials'
            ].join('&'),
            response,
            status,
            data;

        request.addHeader('Content-Type: application/x-www-form-urlencoded');
        response = request.post(tokenUrl, body);
        status = request.getStatus();

        if (status < 200 || status >= 300) {
            throw 'Microsoft identity token request failed with HTTP ' + status + ': ' + response;
        }

        data = JSON.parse(response);
        if (!data.access_token) {
            throw 'Microsoft identity token response did not include access_token.';
        }

        return data.access_token;
    },

    sendMail: function (params, token) {
        var request = new HttpRequest(),
            url = 'https://graph.microsoft.com/v1.0/users/' + encodeURIComponent(params.sender_upn) + '/sendMail',
            recipients = this.parseRecipients(params.to || params.default_to || ''),
            payload,
            response,
            status;

        if (recipients.length === 0) {
            throw 'No email recipients were provided.';
        }

        payload = {
            message: {
                subject: params.subject,
                body: {
                    contentType: 'Text',
                    content: params.message
                },
                toRecipients: recipients
            },
            saveToSentItems: false
        };

        request.addHeader('Authorization: Bearer ' + token);
        request.addHeader('Content-Type: application/json');
        response = request.post(url, JSON.stringify(payload));
        status = request.getStatus();

        if (status !== 202) {
            throw 'Microsoft Graph sendMail failed with HTTP ' + status + ': ' + response;
        }
    }
};

try {
    var params = JSON.parse(value);

    Office365GraphMail.validate(params);
    Office365GraphMail.sendMail(params, Office365GraphMail.requestToken(params));

    return JSON.stringify({
        status: 'sent'
    });
}
catch (error) {
    Zabbix.log(3, '[Office365 Graph Mail] ' + error);
    throw String(error);
}
