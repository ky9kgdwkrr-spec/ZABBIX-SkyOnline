# Zabbix notifications for Office365 and Teams

This folder is the external source of truth for Zabbix notification integrations.
Nothing here is baked into the Zabbix Docker images.

## Files

- `notifications.example.yaml`: template with the expected configuration shape.
- `notifications.sops.yaml`: encrypted runtime configuration. Create this locally; do not store plaintext secrets.
- `media/office365-graph-mail.js`: Zabbix webhook script for Microsoft Graph `sendMail`.
- `media/teams-workflow-alert.js`: Zabbix webhook script for Teams Workflows.
- `../../scripts/apply-zabbix-notifications.sh`: idempotent bootstrap that creates or updates the media types through the Zabbix API.

## Secret workflow

Fill the notification values in `.env`, then generate the encrypted runtime file:

```sh
./scripts/prepare-zabbix-notifications.sh
```

The script creates the age key if it does not exist, writes `notifications.sops.yaml`, and removes the temporary plaintext file. The encrypted file can be backed up with the repo. The private age key path is ignored by git. For production, set `SOPS_AGE_KEY_FILE` in `.env` to a protected host path instead of storing the key under this repository.

Required runtime files before applying notifications:

- the encrypted file referenced by `ZABBIX_NOTIFICATIONS_CONFIG`, defaulting to `zabbix/notifications/notifications.sops.yaml`
- the private age key referenced by `SOPS_AGE_KEY_FILE`, defaulting to `zabbix/notifications/keys/age.key`

If either file is missing, `zabbix-notifications-bootstrap` cannot create the Office 365 or Teams media types in Zabbix.

For production, generate or place the encrypted config under `/etc/zabbix-stack/notifications/notifications.sops.yaml` and set:

```env
ZABBIX_NOTIFICATIONS_CONFIG=/etc/zabbix-stack/notifications/notifications.sops.yaml
SOPS_AGE_KEY_FILE=/etc/zabbix-stack/secrets/age.key
```

## Apply configuration

The normal path is automatic:

```sh
docker compose up -d --build
```

The `zabbix-notifications-bootstrap` service runs after `zabbix-web` is healthy and applies both media types.

If the bootstrap container already exists from a previous run, recreate it explicitly:

```sh
docker compose up -d --build --force-recreate zabbix-notifications-bootstrap
docker compose logs zabbix-notifications-bootstrap
```

Manual re-run for troubleshooting:

```sh
./scripts/apply-zabbix-notifications.sh
```

The script decrypts with `sops -d`, reads JSON from SOPS, and creates or updates:

- `Office365 Graph Mail`
- `Teams Workflow Alert`

Zabbix webhook parameters are stored in the Zabbix database after the bootstrap runs. Keep PostgreSQL backups encrypted and restrict Zabbix Super admin access.
