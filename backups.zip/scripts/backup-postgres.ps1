param(
  [string]$ComposeFile = "docker-compose.yml"
)

$ErrorActionPreference = "Stop"
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupDir = if ($env:POSTGRES_BACKUP_DIR) {
  $env:POSTGRES_BACKUP_DIR
} else {
  Join-Path $PSScriptRoot "..\backups\postgres"
}
New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
$backupDir = Resolve-Path $backupDir
$backupFile = Join-Path $backupDir "zabbix-$timestamp.dump"

docker compose -f $ComposeFile exec -T postgres sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' | Set-Content -Encoding Byte -Path $backupFile
Write-Host "Backup written to $backupFile"
