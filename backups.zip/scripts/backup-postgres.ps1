param(
  [string]$ComposeFile = "docker-compose.yml"
)

$ErrorActionPreference = "Stop"
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupDir = Join-Path $PSScriptRoot "..\backups\postgres"
$backupDir = Resolve-Path $backupDir
$backupFile = Join-Path $backupDir "zabbix-$timestamp.dump"

docker compose -f $ComposeFile exec -T postgres sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' | Set-Content -Encoding Byte -Path $backupFile
Write-Host "Backup written to $backupFile"
