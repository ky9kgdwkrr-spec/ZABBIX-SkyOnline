# Zabbix Docker Platform

## 1. Executive Summary

This stack deploys a role-separated Zabbix platform on Docker Compose for an initial real-world footprint of roughly 100 to 200 monitored hosts. It uses PostgreSQL as the durable database, Zabbix Server, the official Zabbix Nginx/PostgreSQL frontend, Zabbix Web Service for scheduled reports and screenshots, Agent 2 for internal validation, SNMP trap handling, and a small demo web application with a companion Agent 2 container.

The architecture separates frontend, backend, database, and monitoring traffic into different Docker bridge networks. PostgreSQL is never published to the host. Traefik is the only default HTTP entrypoint and publishes the Zabbix Web frontend. Zabbix Proxy and Java Gateway are included as optional Docker Compose profiles so the platform can grow without forcing day-one complexity.

This is not a high-availability design. It is a clean single-node baseline that can be backed up, restored, tuned, and later split into distributed roles.

## 2. Assumptions and Design Criteria

Baseline sizing assumptions:

- 100 to 200 hosts.
- 80 to 150 items per host as an initial planning range.
- Average collection interval between 30 and 60 seconds for standard metrics.
- HTTP checks every 30 to 60 seconds for important web endpoints.
- Estimated new values per second: approximately 250 to 1,000 NVPS depending on templates and intervals.
- History retention: 7 to 30 days for high-volume metrics.
- Trend retention: 180 to 365 days.
- Problem/event retention: 90 to 180 days, adjusted to compliance needs.

Recommended host capacity for the initial all-in-one Docker node:

- CPU: 4 vCPU minimum, 8 vCPU preferred.
- RAM: 8 GB minimum, 16 GB preferred.
- Disk: SSD/NVMe strongly preferred.
- Initial database capacity: 100 to 300 GB, depending on item volume and history retention.
- Filesystem: use a reliable local disk or enterprise storage with consistent fsync latency.

Design criteria:

- Use official Zabbix images and stable pinned tags.
- Separate database, Zabbix server, web UI, HTTP reverse proxy, reporting, traps, agents, optional proxy, and optional JMX.
- Use PostgreSQL for durability and operational familiarity.
- Persist database data, Zabbix operational directories, SNMP trap data, export data, custom scripts, keys, and modules.
- Avoid a single flat Docker network.
- Use Traefik as the HTTP ingress point so application containers do not publish direct HTTP ports. Add TLS termination later when a real domain and certificate policy are available.

Limits of this architecture:

- No Zabbix Server HA.
- PostgreSQL runs in a container on the same Docker host.
- Backups are local unless copied off-host.
- Docker bridge segmentation is useful for clarity and accidental exposure reduction, but it is not a substitute for host firewalling, secrets management, TLS, and OS hardening.

## 3. Selected Versions

Pinned image versions:

| Component | Image/tag | Reason |
|---|---|---|
| PostgreSQL | `postgres:18.4-alpine` | Current stable PostgreSQL major with explicit patch tag. |
| Zabbix Server | `zabbix/zabbix-server-pgsql:7.4.11-alpine` | Current supported Zabbix 7.4 branch, PostgreSQL backend, explicit patch tag. |
| Zabbix Web | `zabbix/zabbix-web-nginx-pgsql:7.4.11-alpine` | Official Nginx + PostgreSQL frontend matching server version. |
| Zabbix Agent 2 | `zabbix/zabbix-agent2:7.4.11-alpine` | Official Agent 2 matching server version. |
| Zabbix Web Service | `zabbix/zabbix-web-service:7.4.11-alpine` | Required for report rendering and screenshots. |
| Zabbix SNMP traps | `zabbix/zabbix-snmptraps:7.4.11-alpine` | Official trap receiver matching server version. |
| Zabbix Proxy | `zabbix/zabbix-proxy-pgsql:7.4.11-alpine` | Optional profile for future distributed collection. |
| Java Gateway | `zabbix/zabbix-java-gateway:7.4.11-alpine` | Optional profile for JMX monitoring. |
| Traefik | `traefik:v3.7.5` | HTTP reverse proxy for the Zabbix frontend. |
| Demo app base | `python:3.13.14-bookworm` | Explicit stable Python image for a small monitored test app. |

Zabbix components should stay on the same patch level unless the official upgrade notes say otherwise.

## 4. Directory Structure

```text
zabbix-docker-platform/
|-- .env.example                         # Template for runtime variables; copy to .env.
|-- .gitignore                           # Excludes secrets, DB files, logs, and generated backups.
|-- docker-compose.yml                   # Main stack with optional profiles.
|-- README.md                            # This operations document.
|-- backups/
|   |-- config/                          # Manual config archives and Zabbix exports.
|   `-- postgres/                        # Local PostgreSQL dumps.
|-- docs/
|   `-- operations.md                    # Place for runbooks, upgrade notes, incident notes.
|-- postgres/
|   |-- conf/postgresql.conf             # PostgreSQL tuning baseline.
|   |-- data/                            # PostgreSQL data directory, generated at runtime.
|   `-- init/01-create-proxy-db.sh       # Initializes optional proxy database on first DB creation.
|-- proxy/
|   |-- enc/                             # Optional proxy TLS/PSK material.
|   |-- externalscripts/                 # Optional proxy external scripts.
|   `-- modules/                         # Optional proxy modules.
|-- scripts/
|   |-- backup-postgres.ps1              # Windows PowerShell PostgreSQL backup helper.
|   |-- backup-postgres.sh               # Linux/macOS PostgreSQL backup helper.
|   `-- restore-postgres.sh              # Basic restore helper.
|-- webapp-demo/
|   |-- Dockerfile                       # Builds the demo monitored app.
|   |-- app.py                           # HTTP app with /, /health, and /info.
|   `-- logs/                            # App access log, generated at runtime.
`-- zabbix/
    |-- agent2/
    |   |-- self/zabbix_agent2.d/        # Custom checks for the stack/host agent.
    |   `-- webapp-demo/zabbix_agent2.d/ # Custom checks for the demo app host.
    |-- export/                          # Zabbix export directory.
    |-- server/
    |   |-- alertscripts/                # Custom alert scripts.
    |   |-- enc/                         # Server-side encryption material.
    |   |-- externalscripts/             # External check scripts.
    |   |-- mibs/                        # Vendor SNMP MIBs.
    |   |-- modules/                     # Zabbix server modules.
    |   `-- ssh_keys/                    # Keys for SSH checks.
    |-- snmptraps/                       # Shared trap spool between trap receiver and server.
    |-- web/
    |   |-- modules/                     # Frontend modules.
    |   `-- nginx/                       # Reserved TLS material for official frontend image.
    `-- web-service/chrome-data/         # Web Service browser state/cache.
```

## 5. Generated Files

Important files are included in this repository folder:

- `docker-compose.yml`: full service topology, networks, ports, volumes, and profiles.
- `.env.example`: all runtime variables and pinned image versions.
- `postgres/conf/postgresql.conf`: PostgreSQL baseline tuning.
- `postgres/init/01-create-proxy-db.sh`: creates the optional proxy database at first initialization.
- `webapp-demo/Dockerfile` and `webapp-demo/app.py`: monitored demo application.
- `zabbix/agent2/webapp-demo/zabbix_agent2.d/webapp-demo.conf`: Agent 2 custom checks for the demo app.
- `scripts/backup-postgres.sh`, `scripts/backup-postgres.ps1`, `scripts/restore-postgres.sh`: backup/restore helpers.

The full file contents are in-place and ready to run. Keep `.env` private.

## 6. Detailed Service Explanation

### `traefik`

- Function: HTTP reverse proxy for the Zabbix Web frontend.
- Ports: `${TRAEFIK_WEB_PORT}:80`, default host port `80`.
- Networks: `frontend`.
- Volumes: Docker socket read-only for dynamic service discovery.
- Key variables: `TRAEFIK_IMAGE`, `TRAEFIK_WEB_BIND_IP`, `TRAEFIK_WEB_PORT`, `TRAEFIK_LOG_LEVEL`, `TRAEFIK_DASHBOARD_HOSTNAME`, `ZABBIX_WEB_HOSTNAME`.
- Design reason: centralizes HTTP ingress and keeps application containers from publishing direct HTTP ports.

### `postgres`

- Function: primary PostgreSQL database for Zabbix Server and optional proxy database initialization.
- Ports: none published to host.
- Networks: `database` only.
- Volumes:
  - `postgres/data` for durable database files.
  - `postgres/conf/postgresql.conf` for explicit DB tuning.
  - `postgres/init` for first-run initialization.
  - `backups/postgres` for local dumps.
- Key variables: `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD`.
- Design reason: no host exposure; database access is limited to Zabbix services on the internal database network.

### `zabbix-server`

- Function: central Zabbix server, pollers, trappers, preprocessors, escalations, reporting workers.
- Ports: `10051/tcp` published for active agents and proxies outside Docker.
- Networks: `backend`, `database`, `monitoring`.
- Volumes:
  - `alertscripts`, `externalscripts`, `modules`, `enc`, `ssh_keys`, `mibs`.
  - shared `snmptraps` spool.
  - `export` for Zabbix export operations.
- Key variables: DB connection, cache sizes, poller counts, web service URL, SNMP trap enablement.
- Design reason: server can reach DB, web service, traps, local agents, and optional proxy while avoiding unnecessary frontend exposure. Internet hosts should normally report with active agents so Zabbix receives inbound connections on `10051/tcp` without initiating connections back to those hosts.

### `zabbix-web`

- Function: official Zabbix web frontend using Nginx and PostgreSQL.
- Ports: none published directly; Traefik routes HTTP traffic to internal port `8080`.
- Networks: `frontend`, `backend`, `database`.
- Volumes: frontend modules and reserved Nginx TLS material.
- Key variables: DB connection, `ZBX_SERVER_HOST`, `ZBX_SERVER_NAME`, `PHP_TZ`.
- Design reason: the UI needs DB and server access, while external HTTP entry is controlled by Traefik.

### `zabbix-web-service`

- Function: report rendering, screenshots, and scheduled report support.
- Ports: none published.
- Networks: `backend`.
- Volumes: browser state/cache under `zabbix/web-service/chrome-data`.
- Key variables: `ZBX_ALLOWEDIP`.
- Design reason: useful operationally for reports; kept internal because only Zabbix Server should call it.

### `zabbix-agent2`

- Function: internal/self monitoring of the Docker host or stack.
- Ports: none published by default.
- Networks: `monitoring`.
- Volumes: Docker socket read-only, host filesystem read-only, custom Agent 2 config.
- Key variables: hostname and server address.
- Design reason: validates agent ingestion from day one and can be expanded for Docker monitoring templates. On non-Linux Docker hosts, review the host filesystem mount.

### `zabbix-snmptraps`

- Function: receives SNMP traps and writes them to the shared trap spool.
- Ports: default host UDP `1162` mapped to container UDP `1162`. Use a host firewall/NAT rule if external devices must send to UDP 162.
- Networks: `monitoring`.
- Volumes: shared `zabbix/snmptraps` and MIBs.
- Design reason: trap handling is isolated from the server container but shares the required spool.

### `webapp-demo`

- Function: simple monitored HTTP application.
- Ports: none published directly; internal endpoint remains `http://webapp-demo:8080`.
- Networks: `frontend`, `monitoring`.
- Volumes: `webapp-demo/logs`.
- Endpoints: `/`, `/health`, `/info`.
- Design reason: gives an internal target for HTTP checks, health checks, logs, and Agent 2 custom checks.

### `webapp-demo-agent2`

- Function: Agent 2 associated with the demo application.
- Ports: none published.
- Networks: `monitoring`.
- Volumes: custom checks and app logs read-only.
- Key items: `webapp.health`, `webapp.info`.
- Design reason: demonstrates the common pattern of app workload plus agent-side checks.

### `zabbix-proxy` optional profile

- Function: prepared local Zabbix proxy using PostgreSQL.
- Activate with: `docker compose --profile proxy up -d`.
- Networks: `backend`, `database`, `monitoring`.
- Design reason: useful when remote sites, network segmentation, or buffered collection become necessary. It is not required for the first 100/200 hosts if latency and network reachability are simple.

### `zabbix-java-gateway` optional profile

- Function: JMX collection endpoint.
- Activate with: `docker compose --profile jmx up -d`.
- Networks: `backend`.
- Design reason: keep it available but disabled until JMX templates are actually used.

## 7. Networks and Addressing

Network segmentation criteria:

- `frontend` is for Traefik and HTTP-facing services.
- `backend` is for Zabbix control-plane communication and is marked `internal`.
- `database` is only for DB traffic and is marked `internal`.
- `monitoring` is the data-plane for agents, traps, and monitored workloads.

Docker assigns container addresses automatically. Do not depend on container IPs; use Docker DNS service names such as `postgres`, `zabbix-server`, `zabbix-web`, `zabbix-web-service`, and `webapp-demo`.

```yaml
networks:
  frontend:
    driver: bridge
  backend:
    driver: bridge
    internal: true
  database:
    driver: bridge
    internal: true
  monitoring:
    driver: bridge
```

Important service names:

- `traefik`: HTTP entrypoint on `frontend`.
- `zabbix-web`: Zabbix frontend on `frontend`, `backend`, and `database`.
- `zabbix-server`: Zabbix server on `backend`, `database`, and `monitoring`.
- `postgres`: PostgreSQL on `database`.
- `zabbix-web-service`: report renderer on `backend`.
- `webapp-demo`: demo app on `frontend` and `monitoring`.

## 8. Persistence, Backups, and Restore

Persisted:

- `postgres/data`: required for all Zabbix data.
- `postgres/conf`: DB tuning and reproducibility.
- `zabbix/server/alertscripts`: custom alert integrations.
- `zabbix/server/externalscripts`: external checks.
- `zabbix/server/modules`: custom modules.
- `zabbix/server/enc`: TLS/PSK material.
- `zabbix/server/ssh_keys`: SSH check keys.
- `zabbix/server/mibs`: SNMP MIBs.
- `zabbix/snmptraps`: trap spool shared by trap receiver and server.
- `zabbix/export`: export/import working directory.
- `zabbix/web/modules`: frontend modules.
- `zabbix/web-service/chrome-data`: report renderer browser state/cache.
- `webapp-demo/logs`: demo app logs for validation.
- `backups`: local backup output.

Not normally persisted:

- Container root filesystems.
- Runtime package caches.
- Zabbix image-bundled default configs.
- Temporary browser cache beyond the mounted web-service data.
- Generated logs inside containers unless needed for compliance. Prefer Docker logging driver or centralized log shipping.

Backup strategy:

1. Run PostgreSQL logical dumps daily:

   ```bash
   ./scripts/backup-postgres.sh
   ```

   On Windows PowerShell:

   ```powershell
   .\scripts\backup-postgres.ps1
   ```

2. Copy `backups/postgres/*.dump` off-host.
3. Back up configuration directories:

   ```bash
   tar -czf backups/config/zabbix-config-$(date -u +%Y%m%d-%H%M%S).tgz .env docker-compose.yml postgres/conf zabbix proxy webapp-demo scripts docs
   ```

4. Export Zabbix templates, hosts, media types, and value maps from the UI or API after major configuration changes.

Basic restore:

```bash
docker compose down
docker compose up -d postgres
./scripts/restore-postgres.sh backups/postgres/zabbix-YYYYMMDD-HHMMSS.dump
docker compose up -d
```

Security considerations:

- Treat `.env`, database dumps, TLS keys, SSH keys, and PSKs as secrets.
- Encrypt off-host backups.
- Test restores regularly.
- Do not expose PostgreSQL.
- Keep Traefik bound intentionally and add TLS before exposing the frontend over untrusted networks.

## 9. Step-by-Step Operation

Prepare directories and environment:

```bash
cd zabbix-docker-platform
cp .env.example .env
```

Edit `.env` and replace all `change-me-*` passwords.

Validate Compose syntax:

```bash
docker compose --env-file .env config
```

Start the core platform:

```bash
docker compose up -d --build
```

Start optional profiles:

```bash
docker compose --profile proxy up -d
docker compose --profile jmx up -d
```

Check status:

```bash
docker compose ps
docker compose logs -f postgres
docker compose logs -f traefik
docker compose logs -f zabbix-server
docker compose logs -f zabbix-web
```

Validate HTTP endpoints:

```bash
curl -H "Host: zabbix.localhost" http://localhost/
curl http://zabbix.localhost/
curl -H "Host: traefik.localhost" http://localhost/dashboard/
curl http://traefik.localhost/dashboard/
```

The Traefik dashboard is enabled for local validation at `http://traefik.localhost/dashboard/`. Before exposing Traefik on an untrusted network, protect the dashboard with authentication and TLS or disable the dashboard route.

Validate restart after server reboot:

```bash
sudo systemctl enable --now docker
docker compose up -d --build
sudo reboot
```

After the host returns:

```bash
docker compose ps
docker compose logs --tail=100 traefik
docker compose logs --tail=100 postgres
docker compose logs --tail=100 zabbix-server
```

All long-running services use `restart: unless-stopped`, so Docker starts them again when the Docker daemon starts. The one-shot `zabbix-notifications-bootstrap` service intentionally uses `restart: "no"` because the applied notification configuration is stored in PostgreSQL and does not need to run on every reboot.

Zabbix runtime configuration is persistent as long as `postgres/data` is preserved. That database stores hosts, templates, users, dashboards, media types, actions, history, trends, and the Office 365/Teams media types after the bootstrap applies them. Recreate `zabbix-notifications-bootstrap` only when notification secrets/scripts changed or after a fresh DB rebuild:

```bash
docker compose up -d --build --force-recreate zabbix-notifications-bootstrap
docker compose logs zabbix-notifications-bootstrap
```

For production on a single disk, do not keep runtime data under a user's home directory. Use the absolute path variables documented in `docs/operations.md` so PostgreSQL data, backups, runtime files, logs, and secrets are separated under `/var/lib`, `/var/backups`, `/var/log`, and `/etc`.

Stop services:

```bash
docker compose down
```

Stop and remove containers while keeping data:

```bash
docker compose down --remove-orphans
```

Update images intentionally:

```bash
docker compose pull
docker compose up -d
docker image prune
```

Before changing Zabbix patch versions, read the official upgrade notes, back up PostgreSQL, and keep all Zabbix component tags aligned.

## 10. Demo Host Registration in Zabbix

First frontend access:

- URL: `http://zabbix.localhost`
- Default Zabbix login: `Admin`
- Default Zabbix password: `zabbix`
- Change the password immediately.

Register the demo app agent:

1. Go to `Data collection` > `Hosts` > `Create host`.
2. Host name: `webapp-demo-agent`.
3. Visible name: `WebApp Demo`.
4. Host group: create or select `Docker demo`.
5. Interface: Agent.
6. DNS name: `webapp-demo-agent2`.
7. Port: `10050`.
8. Add templates:
   - `Linux by Zabbix agent active` or the closest Agent 2 Linux template available in your installed version.
9. Add custom items:
   - Name: `Demo app health endpoint via agent`
   - Type: `Zabbix agent`
   - Key: `webapp.health`
   - Type of information: `Numeric unsigned`
   - Update interval: `30s`
   - Trigger: last value not equal to `200`.
10. Add optional text item:
   - Name: `Demo app info`
   - Type: `Zabbix agent`
   - Key: `webapp.info`
   - Type of information: `Text`
   - Update interval: `5m`

Register web availability:

1. Open the same host or create a separate synthetic host named `webapp-demo-http`.
2. Go to `Web scenarios` > `Create web scenario`.
3. Name: `Demo app HTTP health`.
4. Update interval: `30s`.
5. Step name: `GET /health`.
6. URL: `http://webapp-demo:8080/health`.
7. Required status codes: `200`.
8. Required string: `"status": "ok"` if the UI accepts the exact JSON fragment generated by the app.

Suggested dashboard widgets:

- Problems by severity.
- Latest data filtered by `webapp-demo-agent`.
- Web monitoring availability graph.
- Agent availability.
- Top hosts by trigger count.
- Zabbix server internal queue and cache usage.

## 11. Internet Active Agents

For devices outside the server network, prefer Zabbix Agent 2 in active mode. The monitored device starts an outbound connection to the Zabbix Server, and the server receives it on `10051/tcp`. Do not expose agent port `10050/tcp` from client networks unless you intentionally need passive checks.

Production exposure:

- Publish DNS for the Zabbix server, for example `zabbix.example.com`.
- Open firewall/NAT only for `TCP/10051` to the Docker host running `zabbix-server`.
- Keep Zabbix Web behind Traefik separately on HTTP/HTTPS; agent traffic does not pass through the HTTP reverse proxy.
- Use TLS PSK or certificate encryption for internet agents before broad rollout.

Agent 2 example for an internet client:

```ini
ServerActive=zabbix.example.com:10051
Hostname=unique-client-hostname
```

In the Zabbix UI:

- Create the host with the same `Hostname` value used by the agent.
- Use templates and items of type `Zabbix agent (active)`.
- Avoid passive-only items for internet clients unless a VPN or explicit inbound firewall rule allows Zabbix Server to reach the client on `10050/tcp`.
- For autoregistration, create actions that match active agent metadata or hostnames and attach the intended templates and groups.

Security notes:

- Treat public `10051/tcp` as an internet-facing service.
- Restrict source IPs at the firewall when client egress ranges are known.
- Rotate PSKs/certificates if a client is decommissioned or compromised.
- Monitor Zabbix Server logs and queue health after onboarding many active agents.

## 12. Recommendations for 100/200 Hosts

Server tuning:

- Watch `Zabbix server: Utilization of poller processes`.
- Increase `ZBX_STARTPOLLERS`, `ZBX_STARTHTTPPOLLERS`, `ZBX_STARTPINGERS`, and preprocessors based on utilization, not guesses.
- Watch cache usage. Increase `ZBX_CACHESIZE`, `ZBX_VALUECACHESIZE`, and history caches when they approach sustained high usage.
- Keep `Timeout` reasonable. Long timeouts multiply poller pressure.

PostgreSQL tuning:

- Start with the included `postgresql.conf`, then tune from real metrics.
- Use SSD/NVMe storage.
- Monitor checkpoint frequency, write latency, DB size, dead tuples, and slow queries.
- For larger environments, move PostgreSQL to a dedicated VM/managed database with clear backup and maintenance windows.

Housekeeping and retention:

- Do not keep high-frequency raw history longer than needed.
- Use trends for long-term reporting.
- Prefer per-item retention policies for noisy metrics.
- Avoid enabling discovery templates broadly without reviewing item volume.

When to add a proxy:

- Remote site with unreliable WAN.
- Network segmentation prevents direct server-to-agent checks.
- Need local buffering during central outages.
- Poller load or latency is tied to a specific site.
- Security model requires a collection tier.

When to move beyond this design:

- Sustained NVPS is high enough that PostgreSQL IO becomes the bottleneck.
- Database size and backup windows exceed operational targets.
- Zabbix internal queues remain high after tuning.
- Maintenance windows require HA.
- Multiple sites need autonomy or buffering.

## 13. Future Improvements

- Add TLS to Traefik using ACME or mounted certificates.
- Move passwords to Docker secrets or an external secret manager.
- Add SAML/OIDC/LDAP authentication for the frontend.
- Integrate alerting with email, Teams, Slack, PagerDuty, or incident tools.
- Add GitOps for templates, media types, and exported Zabbix configuration.
- Add PostgreSQL physical backups or WAL archiving for stronger RPO/RTO.
- Evaluate TimescaleDB if history volume and compression needs justify it and the selected Zabbix/PostgreSQL support matrix allows it.
- Add Zabbix Proxy per site.
- Add monitoring of the Docker host, PostgreSQL, Zabbix internals, and backup freshness.
- Add log shipping for Zabbix, PostgreSQL, and the demo app.
- Add high availability with external PostgreSQL, Zabbix HA nodes, and a proper frontend load-balancing design.

## Sources

- Zabbix container documentation: https://www.zabbix.com/documentation/current/en/manual/installation/containers
- Zabbix Docker component repositories: https://www.zabbix.com/container_images
- PostgreSQL official Docker image tags: https://hub.docker.com/_/postgres/tags
- Traefik Docker provider documentation: https://doc.traefik.io/traefik/reference/install-configuration/providers/docker/
- Traefik official Docker image tags: https://hub.docker.com/_/traefik

## Checklist de validación post-despliegue

- `.env` exists and no password remains as `change-me-*`.
- `docker compose --env-file .env config` completes successfully.
- `docker compose ps` shows `traefik`, `postgres`, `zabbix-server`, `zabbix-web`, `zabbix-web-service`, `zabbix-agent2`, `zabbix-snmptraps`, `webapp-demo`, and `webapp-demo-agent2` running.
- PostgreSQL healthcheck is healthy.
- Zabbix frontend opens at `http://zabbix.localhost`.
- Default `Admin/zabbix` login works and password is changed.
- `curl -H "Host: zabbix.localhost" http://localhost/` returns the Zabbix frontend through Traefik.
- Zabbix Server logs show successful DB connection and no repeated cache exhaustion warnings.
- `zabbix/snmptraps` exists and is shared by trap receiver and server.
- A manual PostgreSQL backup completes and creates a `.dump` file.
- Demo host `webapp-demo-agent` is created in Zabbix.
- Item `webapp.health` returns `200`.
- Web scenario `Demo app HTTP health` is green.
- Optional proxy and Java Gateway profiles remain disabled unless intentionally needed.
