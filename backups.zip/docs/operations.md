# Operations notes

Use this folder for runbooks, post-incident notes, version upgrade records, and Zabbix export files. Keep operational decisions close to the Compose stack so another engineer can reconstruct the environment.

## Persistence and automatic restart

The stack is designed so the long-running containers come back automatically after a host reboot, as long as the Docker daemon starts with the operating system:

```sh
sudo systemctl enable --now docker
```

All long-running services in `docker-compose.yml` use `restart: unless-stopped`. This includes Traefik, PostgreSQL, Zabbix Server, Zabbix Web, Zabbix Web Service, Agent 2, SNMP traps, the demo app, and optional proxy/JMX services when those profiles are enabled.

Persistent Zabbix configuration is stored mainly in PostgreSQL under `postgres/data`. This includes hosts, templates, users, dashboards, media types, actions, discovered hosts, history, trends, and frontend configuration. Do not delete or recreate `postgres/data` unless you are intentionally rebuilding or restoring the environment.

Filesystem-backed configuration is mounted from the repository:

- `zabbix/server/alertscripts`, `externalscripts`, `modules`, `enc`, `ssh_keys`, and `mibs`.
- `zabbix/web/modules`.
- `zabbix/web-service/chrome-data`.
- `zabbix/snmptraps` and `zabbix/export`.
- `proxy/*` directories for the optional proxy profile.
- `zabbix/notifications/notifications.sops.yaml` for encrypted notification bootstrap configuration.

The notification bootstrap container is intentionally different: `zabbix-notifications-bootstrap` uses `restart: "no"` because it is an idempotent one-shot job. It applies media type configuration into the Zabbix database and then exits. It does not need to run after every reboot if PostgreSQL data is preserved.

Re-run the notification bootstrap when:

- The Zabbix database was freshly rebuilt or restored to a point before notification media types existed.
- `zabbix/notifications/notifications.sops.yaml` changed.
- A webhook script under `zabbix/notifications/media/` changed.

Use:

```sh
docker compose up -d --build --force-recreate zabbix-notifications-bootstrap
docker compose logs zabbix-notifications-bootstrap
```

Before production, confirm the following after a reboot:

```sh
docker compose ps
docker compose logs --tail=100 postgres
docker compose logs --tail=100 zabbix-server
docker compose logs --tail=100 zabbix-web
docker compose logs --tail=100 traefik
```

## Office365 and Teams alerting

Notification configuration lives outside the containers under `zabbix/notifications/`.
The deployable source of truth is `zabbix/notifications/notifications.sops.yaml`, encrypted with SOPS using age.

### Microsoft 365 prerequisites

1. Create an Entra ID app registration for Zabbix alerting.
2. Add Microsoft Graph application permission `Mail.Send`.
3. Grant admin consent for the permission.
4. Create a client secret and store it only in the SOPS-encrypted notification file.
5. Use a dedicated sender mailbox such as `zabbix-alerts@your-domain`.
6. Restrict the app to the sender mailbox with an Exchange Online application access policy when production governance requires it.

### Teams prerequisite

Create a Teams Workflow using the Teams "When a Teams webhook request is received" trigger and copy the generated webhook URL into the SOPS-encrypted notification file.

### Configuration

Fill the notification values in `.env`, then generate the encrypted runtime file:

```sh
./scripts/prepare-zabbix-notifications.sh
```

Start the stack:

```sh
docker compose up -d --build
```

The `zabbix-notifications-bootstrap` service runs automatically after `zabbix-web` is healthy and creates or updates two Zabbix webhook media types:

- `Office365 Graph Mail`
- `Teams Workflow Alert`

After redeploying containers, no image change is required. If the Zabbix database is kept, the media types remain present. For a fresh database restore or rebuild, explicitly recreate the bootstrap job with `docker compose up -d --build --force-recreate zabbix-notifications-bootstrap`.

The bootstrap currently manages media type definitions and webhook script content. It does not create Zabbix users, assign user media, or create trigger actions. Those objects are persisted in PostgreSQL after you configure them in the UI, but they should be exported or documented for repeatable production rebuilds.

### Validation

1. Run `docker compose --env-file .env config`.
2. Run `sops -d ./zabbix/notifications/notifications.sops.yaml`.
3. Run `docker compose up -d --build --force-recreate zabbix-notifications-bootstrap`.
4. Run `docker compose logs zabbix-notifications-bootstrap`.
5. In Zabbix, use the media type test feature for mail and Teams.
6. Confirm the mail arrives from the service mailbox.
7. Confirm Teams receives the workflow message in the intended channel.

Zabbix stores webhook parameters in its database after the bootstrap applies them. Keep PostgreSQL backups encrypted, protect Super admin accounts, and keep the SOPS private key outside this repository.
