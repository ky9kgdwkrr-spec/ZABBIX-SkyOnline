#!/usr/bin/env sh
set -eu

CERT_DIR="${TRAEFIK_CERTS_DIR:-traefik/certs}"
DAYS="${TRAEFIK_SELF_SIGNED_DAYS:-365}"

mkdir -p "$CERT_DIR"

openssl req \
  -x509 \
  -nodes \
  -newkey rsa:4096 \
  -sha256 \
  -days "$DAYS" \
  -keyout "$CERT_DIR/overlabs.key" \
  -out "$CERT_DIR/overlabs.crt" \
  -subj "/CN=overlabs.com" \
  -addext "subjectAltName=DNS:zabbix.overlabs.com,DNS:traefik.overlabs.com,DNS:airflow.overlabs.com,DNS:overlabs.com"

chmod 0600 "$CERT_DIR/overlabs.key"
chmod 0644 "$CERT_DIR/overlabs.crt"

printf 'Generated %s/overlabs.crt and %s/overlabs.key\n' "$CERT_DIR" "$CERT_DIR"
